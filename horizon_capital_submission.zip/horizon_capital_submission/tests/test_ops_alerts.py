from app import config, ops_alerts


def test_get_alert(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "ARTIFACTS", tmp_path / "artifacts")
    a = ops_alerts.record(code="x", message="m", severity="warning")
    assert ops_alerts.get_alert(a["alert_id"])["code"] == "x"
    assert ops_alerts.get_alert("missing") is None


def test_record_and_ack(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "ARTIFACTS", tmp_path / "artifacts")
    a = ops_alerts.record(code="test_error", message="something failed", severity="error")
    assert a["alert_id"]
    listed = ops_alerts.list_alerts(unacked_only=True)
    assert any(x["alert_id"] == a["alert_id"] for x in listed)
    assert ops_alerts.acknowledge(a["alert_id"])
    assert not any(
        x["alert_id"] == a["alert_id"] and not x.get("acknowledged")
        for x in ops_alerts.list_alerts(unacked_only=True)
    )
