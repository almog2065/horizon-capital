from fastapi.testclient import TestClient

from app import config, ops_alerts
from app.api.app_factory import app


def test_alerts_list_and_detail(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "ARTIFACTS", tmp_path / "artifacts")
    a = ops_alerts.record(
        code="unhandled_exception",
        message="boom",
        severity="critical",
        source="/",
        context={"request_id": "abc123", "traceback": "Traceback...\nValueError: boom"},
    )
    client = TestClient(app)
    r = client.get("/alerts")
    assert r.status_code == 200
    assert a["alert_id"] in r.text
    detail = client.get(f"/alerts/{a['alert_id']}")
    assert detail.status_code == 200
    assert "Stack trace" in detail.text
    assert "abc123" in detail.text
