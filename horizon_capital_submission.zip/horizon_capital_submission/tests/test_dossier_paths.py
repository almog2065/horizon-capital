"""Runtime dossier writes must not touch read-only seed mount."""
from __future__ import annotations

from app import config, dossier_paths


def test_save_writes_runtime_not_seed(tmp_path, monkeypatch):
    seed = tmp_path / "data" / "dossiers"
    seed.mkdir(parents=True)
    (seed / "BTC.json").write_text('{"ticker":"BTC","sector":"Digital Assets"}')
    runtime = tmp_path / "artifacts" / "dossiers"

    monkeypatch.setattr(config, "DATA", tmp_path / "data")
    monkeypatch.setattr(config, "DOSSIERS_SEED_DIR", seed)
    monkeypatch.setattr(config, "DOSSIERS_RUNTIME_DIR", runtime)
    monkeypatch.setattr(config, "ARTIFACTS", tmp_path / "artifacts")

    dossier_paths.save("BTC", {"ticker": "BTC", "sector": "Digital Assets", "updated": True})
    assert (runtime / "BTC.json").exists()
    assert "updated" in (runtime / "BTC.json").read_text()
    # Seed file unchanged
    assert "updated" not in (seed / "BTC.json").read_text()


def test_runtime_overrides_seed(tmp_path, monkeypatch):
    seed = tmp_path / "seed"
    seed.mkdir()
    (seed / "X.json").write_text('{"ticker":"X","name":"seed"}')
    runtime = tmp_path / "runtime"
    runtime.mkdir()
    (runtime / "X.json").write_text('{"ticker":"X","name":"runtime"}')

    monkeypatch.setattr(config, "DOSSIERS_SEED_DIR", seed)
    monkeypatch.setattr(config, "DOSSIERS_RUNTIME_DIR", runtime)

    hit = dossier_paths.load("X")
    assert hit["dossier"]["name"] == "runtime"
