# Horizon Capital — Kubernetes Manifests (Kustomize)

Base + dev/prod overlays for the firm.

## Layout

```
infra/k8s/
├── base/                   # cluster-agnostic manifests
│   ├── namespace.yaml      # PSA: restricted enforce + audit
│   ├── configmap.yaml      # APP_ENV, LOG_LEVEL, scheduler knobs
│   ├── secret.yaml         # placeholder — wire ExternalSecrets in real clusters
│   ├── postgres.yaml       # in-cluster Postgres (dev) — swap for RDS in prod
│   ├── redis.yaml          # in-cluster Redis
│   ├── web-deployment.yaml # FastAPI tier, readiness/liveness/startup probes
│   ├── web-service.yaml    # ClusterIP
│   ├── worker-deployment.yaml  # single replica (no leader election yet)
│   ├── ingress.yaml        # nginx-ingress
│   ├── hpa.yaml            # 2-8 replicas on CPU/mem
│   ├── pdb.yaml            # PodDisruptionBudget — keep ≥1 web pod up
│   └── networkpolicy.yaml  # default-deny + targeted allow
└── overlays/
    ├── dev/                # 1 web replica, DEBUG logs, text format
    └── prod/               # 3 web replicas, larger resources
```

## Apply

```bash
# dev
kubectl apply -k infra/k8s/overlays/dev

# prod
kubectl apply -k infra/k8s/overlays/prod

# verify
kubectl -n horizon-capital get pods,svc,ingress,hpa,pdb
```

## Probes

| Probe        | Path        | Used by           |
|--------------|-------------|-------------------|
| `readinessProbe` | `/readyz`   | LB / Service rotation |
| `livenessProbe`  | `/healthz`  | Restart policy        |
| `startupProbe`   | `/healthz`  | Grace period for boot |

## Worker scaling

Worker is intentionally `replicas: 1` with `strategy: Recreate`. The
scheduler loops are not yet leader-elected. Before scaling, add either:

* Kubernetes Lease + custom leader election (sidecar or in-process)
* External scheduler (e.g., AWS EventBridge → ECS one-shot task)

## Secrets

The `horizon-secrets` placeholder is meant to be replaced by either:

* **External Secrets Operator** sourcing from AWS Secrets Manager / SSM
* **SealedSecrets** for GitOps-friendly storage in-repo
* **Vault Agent Injector** sidecar

Do **not** commit real values.
