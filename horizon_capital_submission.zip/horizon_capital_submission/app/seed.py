"""Seed the RAG corpora and any starter state."""
from __future__ import annotations
import json
import re
from pathlib import Path
from . import config, rag, db


def _chunk_text(text: str, max_chars: int = 600) -> list[str]:
    """Naive paragraph chunker."""
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n|\n##|\n#", text) if p.strip()]
    chunks = []
    for p in paragraphs:
        if len(p) <= max_chars:
            chunks.append(p)
        else:
            for i in range(0, len(p), max_chars):
                chunks.append(p[i:i + max_chars])
    return chunks


def seed_policies():
    for p in sorted(config.POLICIES_DIR.glob("*.md")):
        text = p.read_text()
        chunks = _chunk_text(text)
        for i, chunk in enumerate(chunks):
            # Try to extract a section ref
            m = re.search(r"§\d+", chunk)
            section_ref = (p.stem + " " + m.group(0)) if m else p.stem
            rag.add(
                corpus="policy",
                chunk_id=f"{p.stem}::chunk_{i}",
                text=chunk,
                metadata={
                    "doc": p.stem,
                    "section_ref": section_ref,
                    "version": "1.0",
                },
            )


def seed_past_plans():
    for p in sorted(config.PAST_PLANS_DIR.glob("*.json")):
        plan = json.loads(p.read_text())
        text = (
            f"{plan['ticker']} ({plan['sector']}) plan {plan['plan_id']}: "
            f"{plan['thesis_summary']} "
            f"Outcome: realized_return={plan['outcome']['realized_return_pct']:.2%}, "
            f"holding_period={plan['outcome']['holding_period_days']}d, "
            f"thesis_validated={plan['outcome']['thesis_validated']}. "
            f"Lesson: {plan['lesson_learned']}"
        )
        rag.add(
            corpus="past_plans",
            chunk_id=plan["plan_id"],
            text=text,
            metadata={
                "ticker": plan["ticker"],
                "sector": plan["sector"],
                "outcome": plan["outcome"]["thesis_validated"],
            },
        )


def seed_filings():
    """For the demo, seed a couple of synthetic 'filing chunks' per ticker."""
    synthetic = {
        "MSFT": [
            "Q3 FY26 10-Q excerpt: Azure revenue grew 25% on a constant-currency basis. Operating margin compressed 80 bps year-over-year due to AI infrastructure capex. Capital return continued with 8 billion of buybacks in the quarter. Management reaffirmed FY26 guidance and indicated AI demand visibility extends through next fiscal year.",
            "8-K excerpt: Microsoft announced a 50 billion incremental capex authorization for AI infrastructure over the next two years. The board approved the plan and CFO commented that the firm expects the AI revenue ramp to begin offsetting depreciation by mid-FY27.",
        ],
        "AAPL": [
            "Q2 FY26 10-Q excerpt: Services revenue grew 14% to a record. iPhone revenue declined 2% YoY with China contributing most of the weakness. Gross margin expanded 50 bps driven by Services mix. Capital return reached 27 billion in the quarter.",
            "8-K excerpt: Apple disclosed a stock repurchase program increase of 110 billion alongside a 4% dividend raise.",
        ],
        "NVDA": [
            "Q2 FY26 10-Q excerpt: Data center revenue tripled YoY. Gross margin expanded to 76%. Inventory days grew modestly. Management cautioned on hyperscaler concentration and ongoing export restriction uncertainty.",
            "8-K excerpt: NVIDIA disclosed that new export controls may reduce Q3 revenue by 4 billion. The company is engaging regulators to identify compliant product configurations.",
        ],
    }
    for ticker, chunks in synthetic.items():
        for i, text in enumerate(chunks):
            rag.add(
                corpus="filings",
                chunk_id=f"{ticker}_filing_{i}",
                text=text,
                metadata={"ticker": ticker, "filing_type": "synthetic"},
            )


def seed_news():
    """Pre-seed a few news chunks so search_news returns something meaningful."""
    seeds = [
        ("hist_msft_capex",
         "Microsoft has aggressively increased AI infrastructure capex over the past year. Analysts have debated whether this will pressure margins or build a durable moat. Buy-side opinion is mixed.",
         {"tickers": ["MSFT"], "source": "WSJ"}),
        ("hist_nvda_china",
         "Concerns over US-China chip export restrictions have created intermittent volatility in NVIDIA shares despite strong underlying AI demand.",
         {"tickers": ["NVDA"], "source": "FT"}),
        ("hist_aapl_china_demand",
         "Apple iPhone demand in China has softened amid competition from local handset makers; Services revenue continues to grow.",
         {"tickers": ["AAPL"], "source": "Bloomberg"}),
    ]
    for cid, text, meta in seeds:
        rag.add("news", cid, text, meta)


def seed_all():
    seed_policies()
    seed_past_plans()
    seed_filings()
    seed_news()


if __name__ == "__main__":
    db.init_db()
    rag.init_db()
    seed_all()
    print("Seeded:")
    for c in ("policy", "news", "filings", "past_plans"):
        print(f"  {c}: {rag.count(c)} chunks")
