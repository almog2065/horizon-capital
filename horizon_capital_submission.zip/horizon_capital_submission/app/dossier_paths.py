"""Dossier storage: read-only seed under data/, runtime writes under artifacts/."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

from . import config


def seed_dir() -> Path:
    """Bundled dossiers shipped with the image (may be read-only in Compose)."""
    return config.DOSSIERS_SEED_DIR


def runtime_dir() -> Path:
    """Writable dossiers created at runtime (scan onboarding, updates)."""
    d = config.DOSSIERS_RUNTIME_DIR
    d.mkdir(parents=True, exist_ok=True)
    return d


def resolve_read_path(ticker: str) -> Optional[Path]:
    """Runtime overlay wins over seed files."""
    t = ticker.upper()
    for base in (runtime_dir(), seed_dir()):
        for ext in (".json", ".yaml"):
            p = base / f"{t}{ext}"
            if p.exists():
                return p
    return None


def write_path(ticker: str) -> Path:
    return runtime_dir() / f"{ticker.upper()}.json"


def load(ticker: str) -> dict[str, Any]:
    p = resolve_read_path(ticker)
    if not p:
        return {"found": False, "ticker": ticker.upper(), "not_found_reason": "no_dossier_file"}
    if p.suffix == ".json":
        return {"found": True, "dossier": json.loads(p.read_text()), "source_path": str(p)}
    return {"found": True, "dossier_yaml_raw": p.read_text(), "source_path": str(p)}


def save(ticker: str, dossier: dict) -> Path:
    t = ticker.upper()
    dossier = {**dossier, "ticker": t}
    path = write_path(t)
    path.write_text(json.dumps(dossier, indent=2) + "\n", encoding="utf-8")
    return path


def list_tickers() -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for base in (runtime_dir(), seed_dir()):
        if not base.exists():
            continue
        for p in sorted(base.glob("*.json")):
            if p.stem not in seen:
                seen.add(p.stem)
                out.append(p.stem)
    return out
