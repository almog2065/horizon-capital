"""Operational alerts — capture, persist, and expose firm errors."""
from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any, Literal, Optional

from . import config
from .core.logging import get_logger

log = get_logger("horizon.alerts")

Severity = Literal["info", "warning", "error", "critical"]

_MAX_STORED = 200
_ALERTS_FILE = "ops_alerts.json"


def _path() -> Path:
    p = config.ARTIFACTS / "operations" / _ALERTS_FILE
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def _load() -> list[dict]:
    path = _path()
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return list(data.get("alerts") or [])
    except Exception:
        return []


def _save(alerts: list[dict]) -> None:
    path = _path()
    path.write_text(
        json.dumps({"updated_at": time.time(), "alerts": alerts[-_MAX_STORED:]}, indent=2),
        encoding="utf-8",
    )


def record(
    *,
    code: str,
    message: str,
    severity: Severity = "error",
    source: str = "app",
    context: Optional[dict] = None,
    run_id: Optional[str] = None,
) -> dict:
    """Append an alert and emit structured log."""
    alert = {
        "alert_id": uuid.uuid4().hex[:12],
        "ts": time.time(),
        "code": code,
        "message": message[:2000],
        "severity": severity,
        "source": source,
        "run_id": run_id,
        "context": context or {},
        "acknowledged": False,
    }
    alerts = _load()
    alerts.append(alert)
    _save(alerts)

    log.log(
        40 if severity == "critical" else 30 if severity == "error" else 20,
        "ops-alert code=%s severity=%s source=%s msg=%s",
        code,
        severity,
        source,
        message[:500],
        extra={
            "event": "ops_alert",
            "alert_id": alert["alert_id"],
            "alert_code": code,
            "alert_severity": severity,
            "alert_source": source,
        },
    )

    try:
        from . import metrics_registry
        metrics_registry.inc(
            "horizon_alerts_total",
            severity=severity,
            code=code[:40],
        )
    except Exception:
        pass

    try:
        from . import traces
        traces.record("ops_alert", {
            "alert_id": alert["alert_id"],
            "code": code,
            "severity": severity,
            "message": message[:500],
            "source": source,
        })
    except Exception:
        pass

    return alert


def get_alert(alert_id: str) -> Optional[dict]:
    for a in _load():
        if a.get("alert_id") == alert_id:
            return a
    return None


def list_alerts(
    *,
    limit: int = 40,
    unacked_only: bool = False,
    min_severity: Optional[Severity] = None,
    severity: Optional[Severity] = None,
    code: Optional[str] = None,
) -> list[dict]:
    severity_rank = {"info": 0, "warning": 1, "error": 2, "critical": 3}
    min_rank = severity_rank.get(min_severity or "info", 0)
    out = []
    for a in reversed(_load()):
        if unacked_only and a.get("acknowledged"):
            continue
        if severity and a.get("severity") != severity:
            continue
        if code and a.get("code") != code:
            continue
        if severity_rank.get(a.get("severity", "info"), 0) < min_rank:
            continue
        out.append(a)
        if len(out) >= limit:
            break
    return out


def distinct_codes(limit: int = 30) -> list[str]:
    seen: list[str] = []
    for a in reversed(_load()):
        c = a.get("code")
        if c and c not in seen:
            seen.append(str(c))
        if len(seen) >= limit:
            break
    return seen


def acknowledge(alert_id: str) -> bool:
    alerts = _load()
    found = False
    for a in alerts:
        if a.get("alert_id") == alert_id:
            a["acknowledged"] = True
            a["acked_at"] = time.time()
            found = True
            break
    if found:
        _save(alerts)
    return found


def summary() -> dict[str, Any]:
    alerts = _load()
    open_alerts = [a for a in alerts if not a.get("acknowledged")]
    by_sev: dict[str, int] = {}
    for a in open_alerts:
        s = a.get("severity", "info")
        by_sev[s] = by_sev.get(s, 0) + 1
    return {
        "total_stored": len(alerts),
        "open": len(open_alerts),
        "by_severity": by_sev,
        "latest": open_alerts[-5:] if open_alerts else [],
    }


def format_user_message(alert: dict) -> str:
    return f"[{alert.get('severity', 'error').upper()}] {alert.get('code')}: {alert.get('message', '')}"
