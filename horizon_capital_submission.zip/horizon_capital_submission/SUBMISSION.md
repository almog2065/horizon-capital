# 📦 Submission — Horizon Capital (AI Investment Firm)

This is the submission package for the **Agentic AI Engineer Home Task**.

## 🧭 If you have 60 seconds

1. Look at **`architecture_simple.png`** — the firm as a team of AI workers in plain English.
2. Read **`docs/how-it-works-simple.md`** — 3-minute, no-jargon tour.

## 🧪 If you have 10 minutes (the brief's reviewer timer)

```bash
cp .env.example .env       # the system runs in deterministic mock mode without a real key
make build
make up
open http://127.0.0.1:8080 # the live web dashboard
make report-demo           # writes a daily Excel report under artifacts/reports/
make eval                  # reproducible eval over the sample window
```

## ✅ Requirements traceability — every line of the brief → file

### §2 The Goal

| # | Requirement | Where it lives |
|---|---|---|
| 1 | Paper portfolio + realistic fills (slippage, commission, market hours) + persistent state across runs | `app/portfolio.py` · `app/execution.py` · `app/db.py` · `app/market_calendar.py` · `artifacts/firm.sqlite` (persisted) |
| 2 | Operates continuously during US market hours | `app/scheduler.py` · `app/daily_cadence.py` · `app/workers/scheduler_worker.py` |
| 3 | Multi-agent design with ≥4 specialised agents | **9 agents** in `app/agents/` — `news_triage`, `idea_generator`, `fundamental`, `plan_builder`, `plan_supervisor`, `risk_officer`, `position_monitor`, `firm_manager`, `auditor` |
| 4 | RAG grounding with citations | `app/rag.py` · `app/rag_bootstrap.py` · **4 corpora** under `data/{policies,news_samples,past_plans,dossiers}` |
| 5 | HITL Risk Committee above thresholds | `app/hitl_brief.py` · `app/hitl_sync.py` · `app/agents/risk_officer.py` · `app/templates/hitl.html` |
| 6 | Observability — every invocation/tool/trade traces | `app/traces.py` · `app/core/logging.py` (JSON) · `app/metrics_registry.py` · `observability/prometheus/` · `observability/grafana/` |
| 7 | Daily reports through ≥2 channels | **3 channels** — see §6 below |
| 8 | Evaluable on a reproducible historical window | `evals/run.py` · `evals/replay.py` · `evals/metrics.py` · `evals/data/sample.json` |
| 9 | Token cost, scalability, prod readiness, HA, standardisation | `app/model_routing.py` (cost) · Docker Compose + ECS Fargate + K8s HPA/PDB (scale/HA) · Pydantic + structured logs (standardisation) |

### §4 Production Requirements

| Requirement | Where it lives |
|---|---|
| Persistent portfolio state, crash-safe | `app/db.py` (SQLite by default, Postgres in compose); `artifacts/firm.sqlite` survives container restarts |
| RAG layer — vector store, retrieval, citations, refusal | `app/rag.py` (SQLite vector store) · agents enforce `sources_referenced` on every thesis · `app/agents/fundamental.py` |
| Human-in-the-loop, graph state persists | `app/hitl_brief.py` + LangGraph checkpoint DB (`artifacts/checkpoints.sqlite`) |
| Observability — replay a trade end-to-end from traces alone | `app/traces.py` writes per-step trace rows; `docs/walkthrough-one-trade.md` does exactly that |
| Guardrails — schema validators, hallucination checks, prompt-injection defences, trading limits | Pydantic models in `app/models.py` · `docs/guardrails.md` · risk-policy enforced in `app/agents/risk_officer.py` · `simulate_order` gate in `app/tools.py` |
| Eval harness — portfolio (vs SPY) AND process metrics; runnable in CI | `evals/metrics.py` (portfolio + process + cost) · `evals/run.py --fail-on` for CI thresholds · `.github/workflows/ci.yml` |

### §5 Deliverables

| Spec item | File(s) |
|---|---|
| **A.** Runnable repo, tests, eval harness with sample data, Dockerfile, README clone→demo <10 min | This repo · `Makefile` · `Dockerfile` · `docker-compose.yml` · `tests/` (28 test files) · `evals/data/sample.json` · `README.md` |
| **B.** Architecture diagram — **logical view** (agents, orchestration, RAG, state, HITL, observability) | `architecture.{png,svg,dot}` at repo root + `docs/architecture-diagrams.md` (Mermaid) |
| **B.** Architecture diagram — **deployment view** | `architecture_deployment.{png,svg,dot}` at repo root |
| **B.** *Bonus — plain-English view of every agent and component* | `architecture_simple.{png,svg,dot}` + `docs/how-it-works-simple.md` |
| **C.** README | `README.md` |
| **C.** Technical overview | `docs/technical-overview.md` |
| **C.** Operational runbook | `docs/runbooks/firm-operations.md` + `docs/runbooks/incident-response.md` |
| **C.** Eval report | `docs/eval-results.md` (narrative) + `evals/output/run.json` (machine-readable) |
| **D.** Sample run — at least one historical trading day | `artifacts/reports/2026-05-18/daily.{json,xlsx}` + `evals/output/sample-daily-report.{json,xlsx}` |
| **D.** Trace artifacts for the sample run | `evals/output/sample-traces.jsonl` (10 events) + `evals/output/eval.json` + `evals/output/run.json` |

### §6 Output Channels — three, justified

| # | Channel | Module | Why this combo |
|---|---|---|---|
| 1 | **Web dashboard** (live) | `app/main.py` + `app/templates/*.html` | Interactive — HITL approve/reject, live dossiers, traces. The only channel that supports human action, not just reading. |
| 2 | **Excel daily report** (snapshot) | `app/reports/excel_reporter.py` (stdlib-only XLSX) | Ops-friendly. Lands in inboxes, shared drives, compliance archives. No deps, so the worker container stays tiny. |
| 3 | **JSON log stream** (push) | `app/core/logging.py` | Structured, request-id correlated. Ingestible by Slack webhooks, Loki, CloudWatch, email digests — the universal upstream feed. |

Justification: a *live* channel (web), a *snapshot* channel (Excel), and a *push/stream* channel (JSON logs) cover three different reader needs and degrade independently — if one is down the others still work.

### §8 Evaluation criteria — explicit coverage

| Criterion | How this submission addresses it |
|---|---|
| Multi-agent design with real role-based collaboration | 9 typed agents, side-channel auditor, LangGraph orchestration, explicit hand-offs |
| Production readiness | State (SQLite→Postgres), HITL, observability, guardrails, evals; Docker + Terraform + K8s; non-root + tini + healthchecks |
| RAG grounded-ness | 4 corpora, citations enforced via Pydantic models, refusal when evidence is insufficient (`docs/guardrails.md`) |
| Eval rigor — return AND process metrics, reported honestly | `evals/metrics.py` reports excess-return + max-DD + grounded-ratio + citations/decision + guardrail breaches; sample window trails SPY by 1.04% and the report says so |
| Code quality | Static `ast.parse` clean across 107 files; `ruff` configured in `pyproject.toml`; CI runs lint + tests + eval |
| Architecture clarity | Three diagrams (logical / deployment / plain-English) + ADRs + technical overview |
| Defending trade-offs | `docs/adr/0001-multi-container-deployment.md`, `docs/adr/0002-state-and-iac.md` |
| **Bonus** — IaC, CI/CD, advanced RAG, cost-aware routing, injection defences | Terraform + K8s + GitHub Actions OIDC; `app/model_routing.py`; `docs/guardrails.md` |

## 🛡️ Security & hygiene

- `.env` is **not** in the submission (gitignored). Use `.env.example` and fill in.
- No secrets in the repo. Verified by repo-wide regex scan for `sk-…`, `lsv2_…`, `AKIA…`.
- Container runs **non-root** (uid 1000) with **tini** PID 1 and HEALTHCHECKs.
- Pydantic-validated settings, structured JSON logs, request-id correlation.

## 🔬 What I verified before zipping

- `ast.parse` over **107 Python files** — all OK, no syntax errors.
- The standalone Excel reporter renders without any third-party deps (verified manually in the sandbox).
- The eval harness has sample data committed and an `evals/output/run.json` baseline.
- Sample run committed at `artifacts/reports/2026-05-18/daily.{json,xlsx}` with trace artifacts at `evals/output/sample-traces.jsonl`.
- Repo-wide scan for leftover secrets — clean.
- No leftover `__pycache__`, `.pytest_cache`, `.DS_Store`, or `.env` in the zip.
- All `interview-*` docs and references removed (this is a submission, not a prep packet).

## 🆚 Diff from `horizon_capital_prod`

This submission folder is a snapshot of `horizon_capital_prod` plus:

- 🆕 **`architecture_simple.{png,svg,dot}`** — abstract diagram for non-technical readers
- 🆕 **`architecture_deployment.{png,svg,dot}`** — explicit deployment view (separate from logical)
- 🆕 **`docs/how-it-works-simple.md`** — plain-English explainer
- 🆕 **`SUBMISSION.md`** (this file) — submission cheat-sheet + requirements traceability
- 🆕 **`.gitignore`** — proper top-level ignore (the prod folder only had `.dockerignore`)
- 🔒 **`.env` removed** — the prod folder had a real OpenAI / LangSmith key; stripped here. Use `.env.example`.
- 🗑️ **`docs/interview-brief.md` + `docs/interview-qa.md` removed** — these are personal-prep docs, not deliverables. References scrubbed from `docs/README.md`, `README.md`, `docs/business-case.md`, `docs/demo-script.md`, `docs/architecture-diagrams.md`.
- README updated to surface the new diagrams + the deliverables map.

Everything else is identical to `horizon_capital_prod` and untouched.
